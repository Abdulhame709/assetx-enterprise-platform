@echo off
chcp 65001 >nul
echo.
echo ==================================================
echo   AssetX - تصحيح تقرير الجرد + المنفذ 3001
echo ==================================================
echo.
echo سيتم تشغيل أدوات التصحيح بالترتيب الصحيح.
echo لا تغلق النافذة حتى تظهر كلمة [انتهى] في الأسفل.
echo.
cd /d "%~dp0"
echo --- 1/7: إصلاح نتيجة الجرد (MATCHED + أعمدة الحالة) ---
node "tools\patch-paste.js"
echo.
echo --- 2/7: الترجمة العربية + BOM لملفات CSV ---
node "tools\fix-export-arabic.js"
echo.
echo --- 3/7: خطوط PDF العربية ---
node "tools\fix-pdf-arabic.js"
echo.
echo --- 4/7: ترجمة تفاصيل الحالة في الملاحظات ---
node "tools\fix-export-notes-ar.js"
echo.
echo --- 5/7: أعمدة الجرد الـ12 + الترتيب RTL + عرض الأعمدة ---
node "tools\fix-export-columns-rtl.js"
echo.
echo --- 6/7: إزالة تكرار JOIN في الاستعلام ---
node "tools\fix-export-duplicate-join.js"
echo.
echo --- 7/7: الخادم يعمل على المنفذ 3001 ---
node "tools\fix-backend-port.js"
echo.
echo ==================================================
echo   انتهى
echo   الآن أغلق النوافذ الثلاث ثم شغّل StartX.bat
echo ==================================================
pause
