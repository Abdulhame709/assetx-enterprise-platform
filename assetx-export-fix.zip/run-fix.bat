@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo.
echo ==================================================
echo   AssetX - تصحيح تقرير الجرد + المنفذ 3001
echo ==================================================
echo.

if not exist "backend\src\main.ts" goto wrongfolder

node -v >nul 2>nul
if errorlevel 1 goto nonode

echo جاري تشغيل أدوات التصحيح بالترتيب الصحيح.
echo لا تغلق هذه النافذة حتى تظهر كلمة انتهى في الأسفل.
echo.

echo --- 1/7: نتيجة الجرد وأعمدة الحالة ---
node "tools\patch-paste.js"
echo.
echo --- 2/7: الترجمة العربية و BOM لملفات CSV ---
node "tools\fix-export-arabic.js"
echo.
echo --- 3/7: خطوط PDF العربية ---
node "tools\fix-pdf-arabic.js"
echo.
echo --- 4/7: ترجمة تفاصيل الحالة في الملاحظات ---
node "tools\fix-export-notes-ar.js"
echo.
echo --- 5/7: أعمدة الجرد الاثنا عشر والترتيب والاتساع ---
node "tools\fix-export-columns-rtl.js"
echo.
echo --- 6/7: إزالة تكرار JOIN في الاستعلام ---
node "tools\fix-export-duplicate-join.js"
echo.
echo --- 7/7: الخادم يعمل على المنفذ 3001 ---
node "tools\fix-backend-port.js"
echo.
goto end

:wrongfolder
echo [ERROR] هذا الملف ليس داخل مجلد المشروع.
echo انسخه إلى C:\Users\Elite\assetx-enterprise-platform-v2 ثم شغله مرة أخرى.
echo.
goto end

:nonode
echo [ERROR] لم أجد برنامج Node على الجهاز.
echo اكتب لي هذه الرسالة وسأعطيك الحل.
echo.

:end
echo ==================================================
echo   انتهى
echo   أغلق النوافذ الثلاث ثم شغّل StartX.bat
echo ==================================================
pause
