@echo off
cd /d "%~dp0"
if not exist "tools\fix-asset-type.js" goto nofile
node "tools\fix-asset-type.js"
goto done
:nofile
echo ERROR: tools\fix-asset-type.js was not found next to this file.
:done
echo.
echo Press any key to close this window ...
pause >nul
