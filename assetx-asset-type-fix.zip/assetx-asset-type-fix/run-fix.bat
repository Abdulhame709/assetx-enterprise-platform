@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo.
echo ==================================================
echo   AssetX - show the asset type in the assets list
echo   (fixes the "Type" box that showed a dash)
echo ==================================================
echo.

if not exist "backend\src\main.ts" goto wrongfolder

where node >nul 2>nul
if errorlevel 1 goto nonode

node "tools\fix-asset-type.js"
set "RC=%ERRORLEVEL%"
echo.

if not "%RC%"=="0" goto failed

echo ==================================================
echo   DONE
echo   Close the three windows, then run StartX.bat
echo ==================================================
echo.
pause
exit /b 0

:wrongfolder
echo [ERROR] This file is not inside the project folder.
echo Copy it to C:\Users\Elite\assetx-enterprise-platform-v2 and run it again.
echo.
pause
exit /b 1

:nonode
echo [ERROR] Node.js was not found on this PC.
echo Send me this code: NO-NODE
echo.
pause
exit /b 1

:failed
echo [ERROR] The fix could not be applied. Send me the lines above.
echo.
pause
exit /b 1
