@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo.
echo ==================================================
echo   AssetX - show the asset type in the assets list
echo   (fixes the "Type" box that showed a dash)
echo ==================================================
echo.

if not exist "backend\src\main.ts" goto wrongfolder

where node >nul 2>nul
if errorlevel 1 goto nonode

node "tools\fix-asset-type.js"
set "RC=%ERRORLEVEL%"
echo.

if not "%RC%"=="0" goto failed

rem If the backend runs from a compiled "dist" folder, the source change is not
rem enough: rebuild it here so the new code is actually used after restart.
if not exist "backend\dist\main.js" goto nobuild
echo Rebuilding the backend so the change takes effect ...
pushd backend
if exist "node_modules\typescript\bin\tsc" (
  node "node_modules\typescript\bin\tsc" -p tsconfig.json
) else (
  call npm run build
)
set "BUILD=%ERRORLEVEL%"
popd
if not "%BUILD%"=="0" goto buildfailed
echo Backend rebuilt successfully.
echo.
:nobuild

echo ==================================================
echo   DONE
echo   Close the three windows, then run StartX.bat
echo ==================================================
echo.
pause
exit /b 0

:wrongfolder
echo [ERROR] This file is not inside the project folder.
echo Copy it to C:\Users\Elite\assetx-enterprise-platform-v2 and run it again.
echo.
pause
exit /b 1

:nonode
echo [ERROR] Node.js was not found on this PC.
echo Send me this code: NO-NODE
echo.
pause
exit /b 1

:buildfailed
echo [ERROR] The backend rebuild failed - send me the lines above.
echo (The fix itself was applied; only the rebuild step failed.)
echo.
pause
exit /b 1

:failed
echo [ERROR] The fix could not be applied. Send me the lines above.
echo.
pause
exit /b 1
