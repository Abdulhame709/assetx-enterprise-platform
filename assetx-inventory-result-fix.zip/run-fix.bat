@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo لم يتم العثور على Node.js - افتح Git Bash من هذا المجلد ونفّذ:
  echo     node patch-mobile-result-fix.js
  pause
  exit /b 1
)
echo جاري تطبيق إصلاحات الجرد (نسخ احتياطية .bak-syncfix تُنشأ تلقائيا)...
node patch-mobile-result-fix.js
echo.
pause
